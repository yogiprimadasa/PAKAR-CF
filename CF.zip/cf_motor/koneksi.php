<?php
	error_reporting(E_ALL ^E_NOTICE ^E_DEPRECATED);
	mysql_connect("localhost", "anwar", "1");
	mysql_select_db("anwar_sp_cf_motor");
?>
