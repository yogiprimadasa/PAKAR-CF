<?php
	include("koneksi.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Sistem Pakar Metode CF (Certainty Factor)</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/heroic-features.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>


	    <!-- Navigation -->
	    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
	        <div class="container">
	            <!-- Brand and toggle get grouped for better mobile display -->
	            <div class="navbar-header">
	                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	                    <span class="sr-only">Toggle navigation</span>
	                    <span class="icon-bar"></span>
	                    <span class="icon-bar"></span>
	                    <span class="icon-bar"></span>
	                </button>
	                <a class="navbar-brand" href="index.php">Sistem Pakar CF</a>
	            </div>
	            <!-- Collect the nav links, forms, and other content for toggling -->
	            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	                <ul class="nav navbar-nav">
	                    <li>
	                        <a href="index.php">Home</a>
	                    </li>
	                    <li>
	                        <a href="cf-php-mysql.php">Konsultasi Pakar Metode Certainty Factor</a>
	                    </li>
	                    <li>
	                        <a href="login.php">Login</a>
	                    </li>
	                </ul>
	            </div>
	            <!-- /.navbar-collapse -->
	        </div>
	        <!-- /.container -->
	    </nav>

	    <!-- Page Content -->
	    <div class="container">

	        <!-- Jumbotron Header -->
	        <header class="jumbotron hero-spacer" style="margin-top:-10px;">
	            <h2>Sistem Pakar Metode CF (Certainty Factor)</h2>
	        </header>

					<hr>

					<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#000099">
					  <tr>
					    <td align="center" valign="top" bgcolor="#FFFFFF"><br />
					      <strong>Analisa Menggunakan Sistem Pakar Metode CF (Certainty Factor)</strong><br />
					      <br />
					<?php
						if (!isset($_POST['button']))
						{
					?>
					<form name="form1" method="post" action=""><br>
					  <table align="center" width="100%" border="1" cellspacing="0" cellpadding="5" class="table">
					  <tr>
					  <td id="ignore" bgcolor="#DBEAF5" width="300"><div align="center"><strong><font size="2" face="Arial, Helvetica, sans-serif"><font size="2">GEJALA KERUSAKAN</font> </font></strong></div></td>
					  <?php
					    $q = mysql_query("select * from gejala ORDER BY id_gejala");
					    while ($r = mysql_fetch_array($q))
						{
						?>
					    <tr>
					      <td width="600">
					        <input id="gejala<?php echo $r['id_gejala']; ?>" name="gejala<?php echo $r['id_gejala']; ?>" type="checkbox" value="true">
					        <?php echo $r['nama_gejala']; ?><br/>
					        </td>
					    </tr>
					    <?php } ?>
					    <tr>
					      <td><br><center><input type="submit" name="button" value="Proses" class="btn btn-primary"></center></td>
					    </tr>
					  </table>
					  <br>
					</form>
					  <?php
					  }
					  else
					  {

						$perintah = "SELECT * from gejala";
						$minta =mysql_query($perintah);
						$sql = '';
						$i = 0;
						//mengecek semua chekbox gejala
						while($hs=mysql_fetch_array($minta))
						{
							//jika gejala dipilih
							//menyusun daftar gejala misal '1','2','3' dst utk dipakai di query
							if ($_POST['gejala'.$hs['id_gejala']] == 'true')
							{
								if ($sql == '')
								{
									$sql = "'$hs[id_gejala]'";
								}
								else
								{
									$sql = $sql.",'$hs[id_gejala]'";
								}
							}
							$i++;
						}
						echo $sql.'<br/>';
						empty($daftar_kerusakan);
						empty($daftar_cf);
						if ($sql != '')
						{
							//mencari id_kerusakan di tabel pengetahuan yang gejalanya dipilih
							$perintah = "SELECT id_kerusakan FROM pengetahuan WHERE id_gejala IN ($sql) GROUP BY id_kerusakan ORDER BY id_kerusakan";
							//echo "<br/>".$perintah."<br/>";
							$minta =mysql_query($perintah);
							$id_kerusakan_terbesar = '';
							$nama_kerusakan_terbesar = '';
							$c = 0;
							while($hs=mysql_fetch_array($minta))
							{
								//memproses id kerusakan satu persatu
								$id_kerusakan = $hs['id_kerusakan'];
								$qry = mysql_query("SELECT * FROM kerusakan WHERE id_kerusakan = '$id_kerusakan'");
								$dt = mysql_fetch_array($qry);
								$nama_kerusakan = $dt['nama_kerusakan'];
								$daftar_kerusakan[$c] = $hs['id_kerusakan'];
								echo "<br/>Proses Kerusakan ".$daftar_kerusakan[$c].".".$nama_kerusakan."<br/>==============<br/>";
								//mencari gejala yang mempunyai id kerusakan tersebut, agar bisa menghitung CF dari MB dan MD nya
								$p = "SELECT id_kerusakan, mb, md, id_gejala FROM pengetahuan WHERE id_gejala IN ($sql) AND id_kerusakan = '$id_kerusakan'";
								//echo $p.'<br/>';
								$m =mysql_query($p);
								//mencari jumlah gejala yang ditemukan
								$jml = mysql_num_rows($m);
								//jika gejalanya 1 langsung ketemu CF nya
								echo "jml gejala = ".$jml."<br/>";
								if ($jml == 1)
								{
									$h=mysql_fetch_array($m);
									$mb = $h['mb'];
									$md = $h['md'];
									$cf = $mb - $md;
									$daftar_cf[$c] = $cf;
									//cek apakah kerusakan ini adalah kerusakan dgn CF terbesar ?
									if (($id_kerusakan_terbesar == '') || ($cf_terbesar < $cf))
									{
										$cf_terbesar = $cf;
										$id_kerusakan_terbesar = $id_kerusakan;
										$nama_kerusakan_terbesar = $nama_kerusakan;
									}
									echo "<br/>proses 1<br/>------------------------<br/>";
									echo "mb = ".$mb."<br/>";
									echo "md = ".$md."<br/>";
									echo "cf = mb - md = ".$mb." - ".$md." = ".$cf."<br/><br/><br/>";
								}
								//jika gejala lebih dari satu harus diproses semua gejala
								else if ($jml > 1)
								{
									$i = 1;
									//proses gejala satu persatu
									while($h=mysql_fetch_array($m))
									{
										echo "<br/>proses ".$i."<br/>------------------------------------<br/>";
										//pada gejala yang pertama masukkan MB dan MD menjadi MBlama dan MDlama
										if ($i == 1)
										{
											$mblama = $h['mb'];
											$mdlama = $h['md'];
											echo "mblama = ".$mblama."<br/>";
											echo "mdlama = ".$mdlama."<br/>";
										}
										//pada gejala yang nomor dua masukkan MB dan MD menjadi MBbaru dan MB baru kemudian hitung MBsementara dan MDsementara
										else if ($i == 2)
										{
											$mbbaru = $h['mb'];
											$mdbaru = $h['md'];
											echo "mbbaru = ".$mbbaru."<br/>";
											echo "mdbaru = ".$mdbaru."<br/>";
											$mbsementara = $mblama + ($mbbaru * (1 - $mblama));
											$mdsementara = $mdlama + ($mdbaru * (1 - $mdlama));
											echo "mbsementara = mblama + (mbbaru * (1 - mblama)) = $mblama + ($mbbaru * (1 - $mblama)) = ".$mbsementara."<br/>";
											echo "mdsementara = mdlama + (mdbaru * (1 - mdlama)) = $mdlama + ($mdbaru * (1 - $mdlama)) = ".$mdsementara."<br/>";
											//jika jumlah gejala cuma dua maka CF ketemu
											if ($jml == 2)
											{
												$mb = $mbsementara;
												$md = $mdsementara;
												$cf = $mb - $md;
												echo "mb = mbsementara = ".$mb."<br/>";
												echo "md = mdsementara = ".$md."<br/>";
												echo "cf = mb - md = ".$mb." - ".$md." = ".$cf."<br/><br/><br/>";
												$daftar_cf[$c] = $cf;
												//cek apakah kerusakan ini adalah kerusakan dgn CF terbesar ?
												if (($id_kerusakan_terbesar == '') || ($cf_terbesar < $cf))
												{
													$cf_terbesar = $cf;
													$id_kerusakan_terbesar = $id_kerusakan;
													$nama_kerusakan_terbesar = $nama_kerusakan;
												}
											}
										}
										//pada gejala yang ke 3 dst proses MBsementara dan MDsementara menjadi MBlama dan MDlama
										//MB dan MD menjadi MBbaru dan MDbaru
										//hitung MBsementara dan MD sementara yg sekarang
										else if ($i >= 3)
										{
											$mblama = $mbsementara;
											$mdlama = $mdsementara;
											echo "mblama = mbsementara = ".$mblama."<br/>";
											echo "mdlama = mdsementara = ".$mdlama."<br/>";
											$mbbaru = $h['mb'];
											$mdbaru = $h['md'];
											echo "mbbaru = ".$mbbaru."<br/>";
											echo "mdbaru = ".$mdbaru."<br/>";
											$mbsementara = $mblama + ($mbbaru * (1 - $mblama));
											$mdsementara = $mdlama + ($mdbaru * (1 - $mdlama));
											echo "mbsementara = mblama + (mbbaru * (1 - mblama)) = $mblama + ($mbbaru * (1 - $mblama)) = ".$mbsementara."<br/>";
											echo "mdsementara = mdlama + (mdbaru * (1 - mdlama)) = $mdlama + ($mdbaru * (1 - $mdlama)) = ".$mdsementara."<br/>";
											//jika ini adalah gejala terakhir berarti CF ketemu
											if ($jml == $i)
											{
												$mb = $mbsementara;
												$md = $mdsementara;
												$cf = $mb - $md;
												echo "mb = mbsementara = ".$mb."<br/>";
												echo "md = mdsementara = ".$md."<br/>";
												echo "cf = mb - md = ".$mb." - ".$md." = ".$cf."<br/><br/><br/>";
												$daftar_cf[$c] = $cf;
												//cek apakah kerusakan ini adalah kerusakan dgn CF terbesar ?
												if (($id_kerusakan_terbesar == '') || ($cf_terbesar < $cf))
												{
													$cf_terbesar = $cf;
													$id_kerusakan_terbesar = $id_kerusakan;
													$nama_kerusakan_terbesar = $nama_kerusakan;
												}
											}
										}
										$i++;
									}
								}
								$c++;
							}
						}

						//urutkan daftar gejala berdasarkan besar CF
						for ($i = 0; $i < count($daftar_kerusakan); $i++)
						{
							for ($j = $i + 1; $j < count($daftar_kerusakan); $j++)
							{
								if ($daftar_cf[$j] > $daftar_cf[$i])
								{
									$t = $daftar_cf[$i];
									$daftar_cf[$i] = $daftar_cf[$j];
									$daftar_cf[$j] = $t;

									$t = $daftar_kerusakan[$i];
									$daftar_kerusakan[$i] = $daftar_kerusakan[$j];
									$daftar_kerusakan[$j] = $t;
								}
							}
						}
						echo "Kerusakan terbesar = ".$id_kerusakan_terbesar.".".$nama_kerusakan_terbesar."<br/> <hr>";

						//for ($i = 0; $i < count($daftar_kerusakan); $i++)
						//{
						//	echo $daftar_kerusakan[$i]."=".$daftar_cf[$i]."<br/>";
						//}
						?>
						<table border="0" cellspacing="0" cellpadding="0" width="605">
							<tr>
							<td width="605" class="pageName" align="center"><h3><b>Hasil Konsultasi</b></h3></td>
							</tr>

							<tr>
							<td class="bodyText">
							<p align="justify">
							<table width="100%" class="table" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor=""#BFD0EA"" class="tb_admin">
								<tr>
									<td width="33%" valign="top">Gejala yang dipilih</td>
									<td width="63%"><strong>
									<?php
									$perintah = "SELECT * from gejala";
									$minta =mysql_query($perintah);
									while($hs=mysql_fetch_array($minta))
									{
										if ($_POST['gejala'.$hs['id_gejala']] == 'true')
										{
									?>
										<?php echo $hs['nama_gejala']; ?> <br />
									<?php
										}
									}
									?>
									</strong></td>
								</tr>

								<tr>
								  <td valign="top">&nbsp;</td>
								  <td>&nbsp;</td>
								  </tr>
								<tr>
								  <td>Daftar Kerusakan </td>
								  <td>CF</td>
								  </tr>
								<?php
								for ($i = 0; $i < count($daftar_kerusakan); $i++)
								{
									$perintah = "SELECT * from kerusakan where id_kerusakan = '".$daftar_kerusakan[$i]."'";
									$minta =mysql_query($perintah);
									$hs=mysql_fetch_array($minta);
									//$id_kerusakan_terbesar
									?>
								<tr>
								  <td><?php echo $hs['nama_kerusakan']; ?></td>
								  <td><?php echo $daftar_cf[$i]; ?></td>
								  </tr>
								  <?php
								  }
								  ?>
								<tr>
								  <td valign="top">&nbsp;</td>
								  <td>&nbsp;</td>
								  </tr>
								<tr>
									<td valign="top">Kemungkinan Terbesar Kerusakan </td>
									<?php
									$perintah = "SELECT * from kerusakan where id_kerusakan = '$id_kerusakan_terbesar'";
									$minta =mysql_query($perintah);
									$hs=mysql_fetch_array($minta);
									//$id_kerusakan_terbesar
									?>
									<td><strong><?php echo $hs['nama_kerusakan']; ?> </strong></td>
								</tr>
								<tr>
					              <td>CF</td>
								  <td><strong><?php echo $cf_terbesar; ?></strong></td>
								  </tr>

								<tr>
								  <td>&nbsp;</td>
								  <td>&nbsp;</td>
								  </tr>
							</table>
							</p>
							</td>
							</tr>
							</table>
						<?php
						}
						?>
					</td>
					  </tr>
					  <tr>
					    <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
					    </table></td>
					  </tr>
					</table>
	        <hr>



	        <!-- Footer -->
	        <footer>
	            <div class="row">
	                <div class="col-lg-12">
	                    <p>Copyright &copy; Your Website 2017</p>
	                </div>
	            </div>
	        </footer>

	    </div>
	    <!-- /.container -->

	    <!-- jQuery -->
	    <script src="js/jquery.js"></script>

	    <!-- Bootstrap Core JavaScript -->
	    <script src="js/bootstrap.min.js"></script>

	</body>

	</html>


</body>
</html>
