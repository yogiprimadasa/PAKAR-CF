<?php
	session_start();
	include("koneksi.php");
	if (@$_SESSION['userlogin'] == "")
	{
		header("location:login.php?pesan=Belum Login");
		exit;
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Sistem Pakar Metode CF (Certainty Factor)</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="Dashboard">
	<meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<link href="assets/css/bootstrap.css" rel="stylesheet">
	<!--external css-->
	<link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="assets/css/zabuto_calendar.css">
	<link rel="stylesheet" type="text/css" href="assets/js/gritter/css/jquery.gritter.css" />
	<link rel="stylesheet" type="text/css" href="assets/lineicons/style.css">

	<!-- Custom styles for this template -->
	<link href="assets/css/style.css" rel="stylesheet">
	<link href="assets/css/style-responsive.css" rel="stylesheet">

	<script src="assets/js/chart-master/Chart.js"></script>
</head>
<body>

	<section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="admin.php" class="logo"><b>Panel Admin</b></a>
            <!--logo end-->

            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php" style="color:black;">Logout</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->

			<!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">

              	  <p class="centered"><a href="profile.html"><img src="assets/img/default.jpg" class="img-circle" width="60"></a></p>
              	  <h5 class="centered"><?php echo $_SESSION['userlogin']; ?></h5>

                  <li class="mt">
                      <a href="admin.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>

									<li class="menu">
                      <a href="kerusakan.php">
                          <i class="fa fa-cogs"></i>
                          <span>Kerusakan</span>
                      </a>
                  </li>

									<li class="menu">
                      <a href="gejala.php">
                          <i class="fa fa-th"></i>
                          <span>Gejala Kerusakan</span>
                      </a>
                  </li>

									<li class="menu">
                      <a class="active" href="pengetahuan.php">
                          <i class="fa fa-tasks"></i>
                          <span>Pengetahuan</span>
                      </a>
                  </li>

									<li class="menu">
                      <a href="ganti-password.php">
                          <i class="fa fa-key"></i>
                          <span>Ganti Password</span>
                      </a>
                  </li>

									<li class="menu">
                      <a href="logout.php">
                          <i class="fa fa-power-off"></i>
                          <span>Logout</span>
                      </a>
                  </li>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->

			<section id="main-content">
					<section class="wrapper">
						<br>

						<table width="100%" class="table">
						  <tr>
						    <td height="50" bgcolor="#FFFFFF"><span class="style1">Sistem Pakar Metode CF (Certainty Factor)</span></td>
						  </tr>
						  <tr>
						    <td align="center" valign="top" bgcolor="#FFFFFF"><br />
						      <strong>Data Pengetahuan</strong><br />
						      <br />
						      <table width="100%" class="table table-bordered">
						        <tr>
						          <td width="124" bgcolor="#FFFFFF">ID Pengetahuan</td>
						          <td width="260" bgcolor="#FFFFFF">Nama kerusakan</td>
						          <td width="221" bgcolor="#FFFFFF">Nama Gejala</td>
						          <td width="135" bgcolor="#FFFFFF">MB</td>
						          <td width="111" bgcolor="#FFFFFF">MD</td>
						          <td width="73" bgcolor="#FFFFFF"><a href="add-pengetahuan.php">Add</a></td>
						        </tr>
						        <?php
									//$querypengetahuan = mysql_query("SELECT * FROM pengetahuan LFET JOIN kerusakan ON pengetahuan.id_kerusakan = kerusakan.id_kerusakan LEFT JOIN gejala ON pengetahuan.id_gejala = gejala.id_gejala ORDER BY id_kerusakan, id_gejala");
									$querypengetahuan = mysql_query("SELECT * FROM pengetahuan ORDER BY id_kerusakan, id_gejala");
									while ($datapengetahuan = mysql_fetch_array($querypengetahuan))
									{
										$querykerusakan = mysql_query("SELECT * FROM kerusakan WHERE id_kerusakan = '$datapengetahuan[id_kerusakan]'");
										$datakerusakan = mysql_fetch_array($querykerusakan);
										$querygejala = mysql_query("SELECT * FROM gejala WHERE id_gejala = '$datapengetahuan[id_gejala]'");
										$datagejala = mysql_fetch_array($querygejala);
								?>
						        <tr>
						          <td bgcolor="#FFFFFF"><?php echo $datapengetahuan['id_pengetahuan']; ?></td>
						          <td bgcolor="#FFFFFF"><?php echo $datakerusakan['nama_kerusakan']; ?></td>
						          <td bgcolor="#FFFFFF"><?php echo $datagejala['nama_gejala']; ?></td>
						          <td bgcolor="#FFFFFF"><?php echo $datapengetahuan['mb']; ?></td>
						          <td bgcolor="#FFFFFF"><?php echo $datapengetahuan['md']; ?></td>
						          <td bgcolor="#FFFFFF"><a href="edit-pengetahuan.php?id_pengetahuan=<?php echo $datapengetahuan['id_pengetahuan']; ?>">Edit</a> | <a href="del-pengetahuan.php?id_pengetahuan=<?php echo $datapengetahuan['id_pengetahuan']; ?>">Del</a></td>
						        </tr>
						        <?php
									}
								?>
						      </table>
						      <br />
						    <br /></td>
						  </tr>
						  <tr>
						    <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
						    </table></td>
						  </tr>
						</table>

					</section>
			</section>








<!--footer start-->
<footer class="site-footer">
		<div class="text-center">
				2017 - Sistem Pakar Kerusakan Sepeda Motor
				<a href="#" class="go-top">
						<i class="fa fa-angle-up"></i>
				</a>
		</div>
</footer>
<!--footer end-->
</section>

<!-- js placed at the end of the document so the pages load faster -->
<script src="assets/js/jquery.js"></script>
<script src="assets/js/jquery-1.8.3.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/js/jquery.scrollTo.min.js"></script>
<script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="assets/js/jquery.sparkline.js"></script>


<!--common script for all pages-->
<script src="assets/js/common-scripts.js"></script>

<script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
<script type="text/javascript" src="assets/js/gritter-conf.js"></script>

<!--script for this page-->
<script src="assets/js/sparkline-chart.js"></script>
<script src="assets/js/zabuto_calendar.js"></script>


<script type="application/javascript">
	$(document).ready(function () {
			$("#date-popover").popover({html: true, trigger: "manual"});
			$("#date-popover").hide();
			$("#date-popover").click(function (e) {
					$(this).hide();
			});

			$("#my-calendar").zabuto_calendar({
					action: function () {
							return myDateFunction(this.id, false);
					},
					action_nav: function () {
							return myNavFunction(this.id);
					},
					ajax: {
							url: "show_data.php?action=1",
							modal: true
					},
					legend: [
							{type: "text", label: "Special event", badge: "00"},
							{type: "block", label: "Regular event", }
					]
			});
	});


	function myNavFunction(id) {
			$("#date-popover").hide();
			var nav = $("#" + id).data("navigation");
			var to = $("#" + id).data("to");
			console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
	}
</script>
</body>
</html>
