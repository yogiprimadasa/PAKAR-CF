<?php
	session_start();
	include("koneksi.php");
	if (@$_SESSION['userlogin'] == "")
	{
		header("location:login.php?pesan=Belum Login");
		exit;
	}
	mysql_query("DELETE FROM gejala WHERE id_gejala = '$_GET[id_gejala]'");
	header("location:gejala.php");
?>