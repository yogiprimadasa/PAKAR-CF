<?php
	session_start();
	include("koneksi.php");
	if (@$_SESSION['userlogin'] == "")
	{
		header("location:login.php?pesan=Belum Login");
		exit;
	}
	mysql_query("DELETE FROM pengetahuan WHERE id_pengetahuan = '$_GET[id_pengetahuan]'");
	header("location:pengetahuan.php");
?>