<?php
	session_start();
	include("koneksi.php");
	if (@$_SESSION['userlogin'] == "")
	{
		header("location:login.php?pesan=Belum Login");
		exit;
	}
	if (isset($_POST['button']))
	{
		mysql_query("INSERT INTO pengetahuan(id_kerusakan, id_gejala, mb, md) VALUES('$_POST[id_kerusakan]', '$_POST[id_gejala]', '$_POST[mb]', '$_POST[md]')");
		header("location:pengetahuan.php");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Sistem Pakar Metode CF (Certainty Factor)</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="Dashboard">
	<meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<link href="assets/css/bootstrap.css" rel="stylesheet">
	<!--external css-->
	<link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="assets/css/zabuto_calendar.css">
	<link rel="stylesheet" type="text/css" href="assets/js/gritter/css/jquery.gritter.css" />
	<link rel="stylesheet" type="text/css" href="assets/lineicons/style.css">

	<!-- Custom styles for this template -->
	<link href="assets/css/style.css" rel="stylesheet">
	<link href="assets/css/style-responsive.css" rel="stylesheet">

	<script src="assets/js/chart-master/Chart.js"></script>
</head>
<body>

	<section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="admin.php" class="logo"><b>Panel Admin</b></a>
            <!--logo end-->

            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php" style="color:black;">Logout</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->

			<!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">

              	  <p class="centered"><a href="profile.html"><img src="assets/img/default.jpg" class="img-circle" width="60"></a></p>
              	  <h5 class="centered"><?php echo $_SESSION['userlogin']; ?></h5>

                  <li class="mt">
                      <a href="admin.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>

									<li class="menu">
                      <a href="kerusakan.php">
                          <i class="fa fa-cogs"></i>
                          <span>Kerusakan</span>
                      </a>
                  </li>

									<li class="menu">
                      <a href="gejala.php">
                          <i class="fa fa-th"></i>
                          <span>Gejala Kerusakan</span>
                      </a>
                  </li>

									<li class="menu">
                      <a class="active" href="pengetahuan.php">
                          <i class="fa fa-tasks"></i>
                          <span>Pengetahuan</span>
                      </a>
                  </li>

									<li class="menu">
                      <a href="ganti-password.php">
                          <i class="fa fa-key"></i>
                          <span>Ganti Password</span>
                      </a>
                  </li>

									<li class="menu">
                      <a href="logout.php">
                          <i class="fa fa-power-off"></i>
                          <span>Logout</span>
                      </a>
                  </li>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->

			<section id="main-content">
					<section class="wrapper">
						<br>

						<table width="100%" class="table">
						  <tr>
						    <td height="50" bgcolor="#FFFFFF"><span class="style1">Sistem Pakar Metode CF (Certainty Factor)</span></td>
						  </tr>
						  <tr>
						    <td align="center" valign="top" bgcolor="#FFFFFF"><br />
						      <strong>Tambah Data Pengetahuan</strong><br />
						      <br />
						      <form id="form1" name="form1" method="post" action="">
						        <table width="350" border="0" cellpadding="5" cellspacing="1" bgcolor="#000099">
						          <tr>
						            <td bgcolor="#FFFFFF">Kerusakan</td>
						            <td bgcolor="#FFFFFF"><select name="id_kerusakan" id="id_kerusakan" class="form-control" required>
						                <option value=""></option>
						                <?php
											$querykerusakan = mysql_query("SELECT * FROM kerusakan ORDER BY id_kerusakan");
											while ($datakerusakan = mysql_fetch_array($querykerusakan))
											{
										?>
						                <option value="<?php echo $datakerusakan['id_kerusakan']; ?>"><?php echo $datakerusakan['nama_kerusakan']; ?></option>
						                <?php
											}
										?>
						              </select>            </td>
						          </tr>
						          <tr>
						            <td width="128" bgcolor="#FFFFFF">Gejala</td>
						            <td width="249" bgcolor="#FFFFFF"><select name="id_gejala" id="id_gejala" class="form-control" required>
						                <option value=""></option>
						                <?php
											$querygejala = mysql_query("SELECT * FROM gejala ORDER BY id_gejala");
											while ($datagejala = mysql_fetch_array($querygejala))
											{
										?>
						                <option value="<?php echo $datagejala['id_gejala']; ?>"><?php echo $datagejala['nama_gejala']; ?></option>
						                <?php
											}
										?>
						              </select></td>
						          </tr>
						          <tr>
						            <td bgcolor="#FFFFFF">MB</td>
						            <td bgcolor="#FFFFFF"><input type="text" name="mb" id="mb" class="form-control" required/></td>
						          </tr>
						          <tr>
						            <td bgcolor="#FFFFFF">MD</td>
						            <td bgcolor="#FFFFFF"><input type="text" name="md" id="md" class="form-control" required/></td>
						          </tr>
						          <tr>
						            <td bgcolor="#FFFFFF">&nbsp;</td>
						            <td bgcolor="#FFFFFF"><input type="submit" name="button" id="button" value="Simpan" class="btn btn-primary" style="float:right;"/></td>
						          </tr>
						        </table>
						      </form>
						      <br />
						    <br /></td>
						  </tr>
						  <tr>
						    <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
						    </table></td>
						  </tr>
						</table>

					</section>
			</section>








<!--footer start-->
<footer class="site-footer">
		<div class="text-center">
				2017 - Sistem Pakar Kerusakan Sepeda Motor
				<a href="#" class="go-top">
						<i class="fa fa-angle-up"></i>
				</a>
		</div>
</footer>
<!--footer end-->
</section>

<!-- js placed at the end of the document so the pages load faster -->
<script src="assets/js/jquery.js"></script>
<script src="assets/js/jquery-1.8.3.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/js/jquery.scrollTo.min.js"></script>
<script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="assets/js/jquery.sparkline.js"></script>


<!--common script for all pages-->
<script src="assets/js/common-scripts.js"></script>

<script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
<script type="text/javascript" src="assets/js/gritter-conf.js"></script>

<!--script for this page-->
<script src="assets/js/sparkline-chart.js"></script>
<script src="assets/js/zabuto_calendar.js"></script>


<script type="application/javascript">
	$(document).ready(function () {
			$("#date-popover").popover({html: true, trigger: "manual"});
			$("#date-popover").hide();
			$("#date-popover").click(function (e) {
					$(this).hide();
			});

			$("#my-calendar").zabuto_calendar({
					action: function () {
							return myDateFunction(this.id, false);
					},
					action_nav: function () {
							return myNavFunction(this.id);
					},
					ajax: {
							url: "show_data.php?action=1",
							modal: true
					},
					legend: [
							{type: "text", label: "Special event", badge: "00"},
							{type: "block", label: "Regular event", }
					]
			});
	});


	function myNavFunction(id) {
			$("#date-popover").hide();
			var nav = $("#" + id).data("navigation");
			var to = $("#" + id).data("to");
			console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
	}
</script>
</body>
</html>
